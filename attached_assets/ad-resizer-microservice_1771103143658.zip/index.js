const express = require('express');
const multer = require('multer');
const cors = require('cors');
require('dotenv').config();

const imageResizer = require('./imageResizer');
const adSizes = require('./adSizes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Configure multer for file uploads (in-memory storage)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB max file size
  },
  fileFilter: (req, file, cb) => {
    // Accept images only
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only image files are allowed!'), false);
    }
    cb(null, true);
  },
});

/**
 * Serve test interface
 */
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/test.html');
});

/**
 * Health check endpoint
 */
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'Ad Resizer Microservice',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

/**
 * Get all available ad sizes
 */
app.get('/api/sizes', (req, res) => {
  const { platform } = req.query;
  
  if (platform) {
    if (!adSizes[platform]) {
      return res.status(404).json({
        error: `Platform '${platform}' not found`,
        availablePlatforms: Object.keys(adSizes)
      });
    }
    return res.json({
      platform,
      sizes: adSizes[platform]
    });
  }

  // Return all sizes grouped by platform
  const totalSizes = Object.values(adSizes).reduce((sum, platform) => sum + platform.length, 0);
  
  res.json({
    platforms: Object.keys(adSizes),
    totalSizes,
    sizes: adSizes
  });
});

/**
 * Resize image from URL
 * POST /api/resize/url
 * Body: { url: string, platforms?: string[], fit?: string }
 */
app.post('/api/resize/url', async (req, res) => {
  try {
    const { url, platforms, fit = 'cover' } = req.body;

    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    // Fetch image from URL
    console.log(`Fetching image from: ${url}`);
    const imageBuffer = await imageResizer.fetchImageFromUrl(url);

    // Get original image metadata
    const metadata = await imageResizer.getImageMetadata(imageBuffer);

    // Determine which platforms to process
    let selectedSizes = [];
    if (platforms && Array.isArray(platforms)) {
      platforms.forEach(platform => {
        if (adSizes[platform]) {
          selectedSizes = [...selectedSizes, ...adSizes[platform]];
        }
      });
    } else {
      // Process all platforms
      Object.values(adSizes).forEach(platformSizes => {
        selectedSizes = [...selectedSizes, ...platformSizes];
      });
    }

    if (selectedSizes.length === 0) {
      return res.status(400).json({ error: 'No valid platforms specified' });
    }

    // Process image for all sizes
    console.log(`Processing ${selectedSizes.length} ad sizes...`);
    const results = await imageResizer.processImageForSizes(imageBuffer, selectedSizes, fit);

    res.json({
      success: true,
      original: {
        url,
        metadata
      },
      processed: {
        count: results.length,
        successCount: results.filter(r => !r.error).length,
        errorCount: results.filter(r => r.error).length,
      },
      results: results.map(r => ({
        name: r.name,
        width: r.width,
        height: r.height,
        aspectRatio: r.aspectRatio,
        base64: r.base64, // Base64 encoded image
        sizeBytes: r.size,
        error: r.error,
      }))
    });

  } catch (error) {
    console.error('Error processing image from URL:', error);
    res.status(500).json({
      error: 'Failed to process image',
      message: error.message
    });
  }
});

/**
 * Resize uploaded image
 * POST /api/resize/upload
 * Form data: image (file), platforms (optional), fit (optional)
 */
app.post('/api/resize/upload', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file uploaded' });
    }

    const imageBuffer = req.file.buffer;
    const fit = req.body.fit || 'cover';
    const platforms = req.body.platforms ? JSON.parse(req.body.platforms) : null;

    // Get original image metadata
    const metadata = await imageResizer.getImageMetadata(imageBuffer);

    // Determine which platforms to process
    let selectedSizes = [];
    if (platforms && Array.isArray(platforms)) {
      platforms.forEach(platform => {
        if (adSizes[platform]) {
          selectedSizes = [...selectedSizes, ...adSizes[platform]];
        }
      });
    } else {
      // Process all platforms
      Object.values(adSizes).forEach(platformSizes => {
        selectedSizes = [...selectedSizes, ...platformSizes];
      });
    }

    if (selectedSizes.length === 0) {
      return res.status(400).json({ error: 'No valid platforms specified' });
    }

    // Process image for all sizes
    console.log(`Processing ${selectedSizes.length} ad sizes...`);
    const results = await imageResizer.processImageForSizes(imageBuffer, selectedSizes, fit);

    res.json({
      success: true,
      original: {
        filename: req.file.originalname,
        metadata
      },
      processed: {
        count: results.length,
        successCount: results.filter(r => !r.error).length,
        errorCount: results.filter(r => r.error).length,
      },
      results: results.map(r => ({
        name: r.name,
        width: r.width,
        height: r.height,
        aspectRatio: r.aspectRatio,
        base64: r.base64, // Base64 encoded image
        sizeBytes: r.size,
        error: r.error,
      }))
    });

  } catch (error) {
    console.error('Error processing uploaded image:', error);
    res.status(500).json({
      error: 'Failed to process image',
      message: error.message
    });
  }
});

/**
 * Resize image for specific platforms only
 * POST /api/resize/selective
 * Body: { url?: string, platforms: string[], fit?: string }
 * Or Form data: image (file), platforms (array), fit (optional)
 */
app.post('/api/resize/selective', upload.single('image'), async (req, res) => {
  try {
    let imageBuffer;
    let source = {};

    // Check if image comes from URL or upload
    if (req.file) {
      imageBuffer = req.file.buffer;
      source = { type: 'upload', filename: req.file.originalname };
    } else if (req.body.url) {
      imageBuffer = await imageResizer.fetchImageFromUrl(req.body.url);
      source = { type: 'url', url: req.body.url };
    } else {
      return res.status(400).json({ error: 'Either file upload or URL is required' });
    }

    const platforms = req.body.platforms ? 
      (typeof req.body.platforms === 'string' ? JSON.parse(req.body.platforms) : req.body.platforms) 
      : [];
    const fit = req.body.fit || 'cover';

    if (!Array.isArray(platforms) || platforms.length === 0) {
      return res.status(400).json({ 
        error: 'Platforms array is required',
        availablePlatforms: Object.keys(adSizes)
      });
    }

    // Get original image metadata
    const metadata = await imageResizer.getImageMetadata(imageBuffer);

    // Get sizes for selected platforms
    let selectedSizes = [];
    platforms.forEach(platform => {
      if (adSizes[platform]) {
        selectedSizes = [...selectedSizes, ...adSizes[platform]];
      }
    });

    if (selectedSizes.length === 0) {
      return res.status(400).json({ 
        error: 'No valid platforms found',
        availablePlatforms: Object.keys(adSizes)
      });
    }

    // Process image for selected sizes
    console.log(`Processing ${selectedSizes.length} ad sizes for platforms: ${platforms.join(', ')}`);
    const results = await imageResizer.processImageForSizes(imageBuffer, selectedSizes, fit);

    res.json({
      success: true,
      source,
      original: { metadata },
      platforms: platforms,
      processed: {
        count: results.length,
        successCount: results.filter(r => !r.error).length,
        errorCount: results.filter(r => r.error).length,
      },
      results: results.map(r => ({
        name: r.name,
        width: r.width,
        height: r.height,
        aspectRatio: r.aspectRatio,
        base64: r.base64,
        sizeBytes: r.size,
        error: r.error,
      }))
    });

  } catch (error) {
    console.error('Error in selective resize:', error);
    res.status(500).json({
      error: 'Failed to process image',
      message: error.message
    });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Error:', error);
  res.status(error.status || 500).json({
    error: error.message || 'Internal server error'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Ad Resizer Microservice running on port ${PORT}`);
  console.log(`📊 Supporting ${Object.keys(adSizes).length} platforms`);
  console.log(`🎨 Total ad sizes: ${Object.values(adSizes).reduce((sum, p) => sum + p.length, 0)}`);
  console.log('\nEndpoints:');
  console.log(`  GET  /health - Health check`);
  console.log(`  GET  /api/sizes - Get all available sizes`);
  console.log(`  POST /api/resize/url - Resize from URL`);
  console.log(`  POST /api/resize/upload - Resize uploaded file`);
  console.log(`  POST /api/resize/selective - Resize for specific platforms`);
});

module.exports = app;

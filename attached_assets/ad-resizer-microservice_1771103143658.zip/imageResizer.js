const sharp = require('sharp');
const axios = require('axios');

/**
 * Image Resizer Service
 * Handles all image processing operations
 */

class ImageResizerService {
  /**
   * Fetch image from URL
   * @param {string} url - Image URL
   * @returns {Promise<Buffer>} Image buffer
   */
  async fetchImageFromUrl(url) {
    try {
      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 10000,
        maxContentLength: 50 * 1024 * 1024, // 50MB max
      });
      return Buffer.from(response.data);
    } catch (error) {
      throw new Error(`Failed to fetch image from URL: ${error.message}`);
    }
  }

  /**
   * Resize image to specific dimensions
   * @param {Buffer} imageBuffer - Source image buffer
   * @param {number} width - Target width
   * @param {number} height - Target height
   * @param {string} fit - Resize fit option (cover, contain, fill, inside, outside)
   * @returns {Promise<Buffer>} Resized image buffer
   */
  async resizeImage(imageBuffer, width, height, fit = 'cover') {
    try {
      return await sharp(imageBuffer)
        .resize(width, height, {
          fit: fit,
          position: 'center',
          background: { r: 255, g: 255, b: 255, alpha: 1 }
        })
        .jpeg({ quality: 90 })
        .toBuffer();
    } catch (error) {
      throw new Error(`Failed to resize image: ${error.message}`);
    }
  }

  /**
   * Process image for multiple ad sizes
   * @param {Buffer} imageBuffer - Source image buffer
   * @param {Array} sizes - Array of size specifications
   * @param {string} fit - Resize fit option
   * @returns {Promise<Array>} Array of resized images with metadata
   */
  async processImageForSizes(imageBuffer, sizes, fit = 'cover') {
    const results = [];

    for (const size of sizes) {
      try {
        const resizedBuffer = await this.resizeImage(
          imageBuffer,
          size.width,
          size.height,
          fit
        );

        results.push({
          name: size.name,
          width: size.width,
          height: size.height,
          aspectRatio: size.aspectRatio,
          buffer: resizedBuffer,
          base64: resizedBuffer.toString('base64'),
          size: resizedBuffer.length,
        });
      } catch (error) {
        console.error(`Error processing size ${size.name}:`, error);
        results.push({
          name: size.name,
          error: error.message,
        });
      }
    }

    return results;
  }

  /**
   * Get image metadata
   * @param {Buffer} imageBuffer - Image buffer
   * @returns {Promise<Object>} Image metadata
   */
  async getImageMetadata(imageBuffer) {
    try {
      const metadata = await sharp(imageBuffer).metadata();
      return {
        width: metadata.width,
        height: metadata.height,
        format: metadata.format,
        size: metadata.size,
        aspectRatio: (metadata.width / metadata.height).toFixed(2),
      };
    } catch (error) {
      throw new Error(`Failed to get image metadata: ${error.message}`);
    }
  }

  /**
   * Validate image buffer
   * @param {Buffer} imageBuffer - Image buffer to validate
   * @returns {Promise<boolean>} Validation result
   */
  async validateImage(imageBuffer) {
    try {
      await sharp(imageBuffer).metadata();
      return true;
    } catch (error) {
      return false;
    }
  }
}

module.exports = new ImageResizerService();

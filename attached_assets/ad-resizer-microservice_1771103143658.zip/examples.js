/**
 * Example Usage Script
 * Demonstrates how to call the Ad Resizer Microservice
 * 
 * Run with: node examples.js
 * (Make sure the server is running first with: npm start)
 */

const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');

const BASE_URL = 'http://localhost:3000';

// Example 1: Get all available sizes
async function getAllSizes() {
  console.log('\n📊 Example 1: Get All Available Sizes\n');
  
  try {
    const response = await axios.get(`${BASE_URL}/api/sizes`);
    const data = response.data;
    
    console.log(`✅ Found ${data.totalSizes} ad sizes across ${data.platforms.length} platforms`);
    console.log('Platforms:', data.platforms.join(', '));
    
    return data;
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

// Example 2: Get sizes for specific platform
async function getSizesForPlatform(platform) {
  console.log(`\n📊 Example 2: Get Sizes for ${platform}\n`);
  
  try {
    const response = await axios.get(`${BASE_URL}/api/sizes`, {
      params: { platform }
    });
    const data = response.data;
    
    console.log(`✅ Found ${data.sizes.length} sizes for ${platform}:`);
    data.sizes.forEach(size => {
      console.log(`  - ${size.name}: ${size.width}x${size.height} (${size.aspectRatio})`);
    });
    
    return data;
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

// Example 3: Resize from URL for all platforms
async function resizeFromUrl(imageUrl) {
  console.log('\n🎨 Example 3: Resize Image from URL (All Platforms)\n');
  
  try {
    const response = await axios.post(`${BASE_URL}/api/resize/url`, {
      url: imageUrl,
      fit: 'cover'
    });
    const data = response.data;
    
    console.log('✅ Original Image:');
    console.log(`  URL: ${data.original.url}`);
    console.log(`  Size: ${data.original.metadata.width}x${data.original.metadata.height}`);
    console.log(`  Format: ${data.original.metadata.format}`);
    
    console.log('\n✅ Processed Results:');
    console.log(`  Total: ${data.processed.count} sizes`);
    console.log(`  Success: ${data.processed.successCount}`);
    console.log(`  Errors: ${data.processed.errorCount}`);
    
    console.log('\n📋 First 5 Results:');
    data.results.slice(0, 5).forEach(result => {
      if (!result.error) {
        console.log(`  ✓ ${result.name}: ${result.width}x${result.height} (${(result.sizeBytes / 1024).toFixed(1)} KB)`);
      }
    });
    
    return data;
  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.response) {
      console.error('Response:', error.response.data);
    }
  }
}

// Example 4: Resize for specific platforms only
async function resizeForPlatforms(imageUrl, platforms) {
  console.log(`\n🎯 Example 4: Resize for Specific Platforms: ${platforms.join(', ')}\n`);
  
  try {
    const response = await axios.post(`${BASE_URL}/api/resize/selective`, {
      url: imageUrl,
      platforms: platforms,
      fit: 'cover'
    });
    const data = response.data;
    
    console.log('✅ Processed Results:');
    console.log(`  Platforms: ${data.platforms.join(', ')}`);
    console.log(`  Total sizes: ${data.processed.count}`);
    console.log(`  Success: ${data.processed.successCount}`);
    
    console.log('\n📋 All Results:');
    data.results.forEach(result => {
      if (!result.error) {
        console.log(`  ✓ ${result.name}: ${result.width}x${result.height}`);
      }
    });
    
    // Optional: Save first result as example
    if (data.results.length > 0 && data.results[0].base64) {
      const firstResult = data.results[0];
      const buffer = Buffer.from(firstResult.base64, 'base64');
      const filename = `example_${firstResult.name.replace(/\s+/g, '_').toLowerCase()}.jpg`;
      
      fs.writeFileSync(filename, buffer);
      console.log(`\n💾 Saved example: ${filename}`);
    }
    
    return data;
  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.response) {
      console.error('Response:', error.response.data);
    }
  }
}

// Example 5: Upload and resize local file
async function resizeUploadedFile(filePath, platforms = null) {
  console.log('\n📤 Example 5: Upload and Resize Local File\n');
  
  try {
    const form = new FormData();
    form.append('image', fs.createReadStream(filePath));
    
    if (platforms) {
      form.append('platforms', JSON.stringify(platforms));
    }
    
    form.append('fit', 'cover');
    
    const response = await axios.post(`${BASE_URL}/api/resize/upload`, form, {
      headers: form.getHeaders()
    });
    const data = response.data;
    
    console.log('✅ File uploaded and processed:');
    console.log(`  Original: ${data.original.filename}`);
    console.log(`  Size: ${data.original.metadata.width}x${data.original.metadata.height}`);
    console.log(`  Processed: ${data.processed.successCount} sizes`);
    
    return data;
  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.response) {
      console.error('Response:', error.response.data);
    }
  }
}

// Run examples
async function runExamples() {
  console.log('🚀 Ad Resizer Microservice - Example Usage\n');
  console.log('Make sure the server is running on http://localhost:3000\n');
  console.log('=' .repeat(60));
  
  // Example 1: Get all sizes
  await getAllSizes();
  
  // Example 2: Get sizes for Facebook
  await getSizesForPlatform('facebook');
  
  // Example 3: Resize a sample image from URL
  // Using a sample image (replace with your own)
  const sampleImageUrl = 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4';
  await resizeFromUrl(sampleImageUrl);
  
  // Example 4: Resize for specific platforms
  await resizeForPlatforms(sampleImageUrl, ['facebook', 'instagram']);
  
  // Example 5: Upload local file (uncomment if you have a local image)
  // await resizeUploadedFile('./your-image.jpg', ['facebook']);
  
  console.log('\n' + '='.repeat(60));
  console.log('\n✅ All examples completed!\n');
}

// Run if called directly
if (require.main === module) {
  runExamples().catch(console.error);
}

module.exports = {
  getAllSizes,
  getSizesForPlatform,
  resizeFromUrl,
  resizeForPlatforms,
  resizeUploadedFile
};
